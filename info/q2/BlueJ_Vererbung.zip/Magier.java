/**
 * Unterklasse Magier
 * 
 * Erbt von Spielfigur (extends Spielfigur).
 * Ein Magier besitzt Mana. Wenn genuegend Mana vorhanden ist, verbraucht
 * sein Angriff Mana und loest einen maechtigen Zauberangriff (doppelter Schaden) aus.
 * Ist kein Mana vorhanden, greift er auf den Basisangriff der Oberklasse zurueck.
 * 
 * @author Informatik Q2
 * @version Schuljahr 2026/27
 */
public class Magier extends Spielfigur {
    // Spezifisches zusaetzliches Attribut des Magiers
    private int mana;

    /**
     * Konstruktor des Magiers.
     * 
     * WICHTIG: Erste Zeile MUSS super(...) sein!
     * 
     * @param pName          Name des Magiers
     * @param pLebenspunkte  Start-Lebenspunkte
     * @param pBasisSchaden  Standard-Schadenswert
     * @param pMana          Start-Mana fuer magische Attacken
     */
    public Magier(String pName, int pLebenspunkte, int pBasisSchaden, int pMana) {
        // 1. Initialisierung der Oberklasse Spielfigur
        super(pName, pLebenspunkte, pBasisSchaden);
        // 2. Eigenes Attribut setzen
        this.mana = Math.max(0, pMana);
    }

    /**
     * BEISPIEL FUER METHODEN-UEBERSCHREIBEN (Overriding):
     * Exakt gleiche Signatur wie in Spielfigur: angreifen(Spielfigur pZiel).
     * Wenn mindestens 10 Mana vorhanden sind, wird ein Zauber mit doppeltem Schaden
     * gewirkt. Andernfalls greift der Magier via super.angreifen(...) mit dem
     * Standard-Angriff der Oberklasse an.
     */
    @Override
    public void angreifen(Spielfigur pZiel) {
        if (pZiel == null || !istLebendig()) {
            return;
        }

        if (this.mana >= 10) {
            this.mana -= 10;
            int zauberSchaden = this.basisSchaden * 2;
            System.out.println("[" + this.name + "] wirkt Feuerball auf [" + pZiel.getName() + "]! (-10 Mana, " + zauberSchaden + " Zauberschaden, Restmana: " + this.mana + ")");
            pZiel.nimmSchaden(zauberSchaden);
        } else {
            System.out.println("[" + this.name + "] hat nicht genug Mana fuer einen Zauber (nur " + this.mana + " Mana). Greift mit Stab an!");
            // Rueckgriff auf die Basismethode der Oberklasse via super:
            super.angreifen(pZiel);
        }
    }

    /**
     * Spezifische Methode des Magiers: Meditieren, um Mana zu regenerieren.
     * 
     * @param pMenge Aufgelaedtes Mana
     */
    public void meditieren(int pMenge) {
        if (pMenge > 0) {
            this.mana += pMenge;
            System.out.println("[" + this.name + "] meditiert und regeneriert " + pMenge + " Mana. Aktuelles Mana: " + this.mana);
        }
    }

    /**
     * Ueberschreibt statusAusgeben(), um zusaetzlich das Mana anzuzeigen.
     */
    @Override
    public void statusAusgeben() {
        super.statusAusgeben(); // Ruft die Statusausgabe der Oberklasse auf
        System.out.println("Mana:         " + this.mana);
    }

    public int getMana() {
        return this.mana;
    }
}
