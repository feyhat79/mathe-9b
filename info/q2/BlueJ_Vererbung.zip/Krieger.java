/**
 * Unterklasse Krieger
 * 
 * Erbt von Spielfigur (extends Spielfigur).
 * Ein Krieger verfuegt zusaetzlich ueber eine Ruestung, die erlittenen Schaden verringert.
 * 
 * @author Informatik Q2
 * @version Schuljahr 2026/27
 */
public class Krieger extends Spielfigur {
    // protected: Sichtbar in dieser Klasse UND in weiteren Spezialisierungen (z. B. Paladin)
    protected int ruestung;

    /**
     * Konstruktor des Kriegers.
     * 
     * WICHTIG: Die allererste Anweisung MUSS der super(...)-Aufruf sein,
     * um die Oberklasse Spielfigur zu initialisieren!
     * 
     * @param pName          Name des Kriegers
     * @param pLebenspunkte  Start-Lebenspunkte
     * @param pBasisSchaden  Standard-Schadenswert
     * @param pRuestung      Ruestungswert zum Abfangen von Schaden
     */
    public Krieger(String pName, int pLebenspunkte, int pBasisSchaden, int pRuestung) {
        // 1. Aufruf des Oberklassen-Konstruktors (Fundament-Prinzip)
        super(pName, pLebenspunkte, pBasisSchaden);
        // 2. Initialisierung des eigenen Krieger-Attributs
        this.ruestung = Math.max(0, pRuestung);
    }

    /**
     * BEISPIEL FUER METHODEN-UEBERSCHREIBEN (Overriding):
     * Exakt gleiche Signatur wie in Spielfigur (gleicher Name, gleiche Parameter).
     * Die Unterklasse passt das Verhalten an: Die Ruestung faengt Schaden ab!
     * 
     * Anschliessend delegiert super.nimmSchaden(...) die eigentliche
     * Schadensberechnung und Lebenspunkte-Reduktion an die Oberklasse.
     */
    @Override
    public void nimmSchaden(int pSchaden) {
        int effektiverSchaden = pSchaden - this.ruestung;
        if (effektiverSchaden < 0) {
            effektiverSchaden = 0;
        }
        System.out.println("[" + this.name + "] blockt mit Ruestung (" + this.ruestung + " Schaden absorbiert). Effektiver Schaden: " + effektiverSchaden);
        
        // super.nimmSchaden ruft die bewaehrte Basislogik der Oberklasse auf!
        super.nimmSchaden(effektiverSchaden);
    }

    /**
     * Spezifische Methode des Kriegers: Schildwall aktivieren.
     * Erhoeht den Ruestungswert.
     * 
     * @param pBonus Zusaetzliche Ruestungspunkte
     */
    public void ruestungErhoehen(int pBonus) {
        if (pBonus > 0) {
            this.ruestung += pBonus;
            System.out.println("[" + this.name + "] verstaerkt seine Ruestung auf " + this.ruestung + " Punkte.");
        }
    }

    /**
     * Ueberschreibt statusAusgeben(), um zusaetzlich die Ruestung anzuzeigen.
     */
    @Override
    public void statusAusgeben() {
        super.statusAusgeben(); // Gibt Name, LP und Schaden via Oberklasse aus
        System.out.println("Ruestung:     " + this.ruestung);
    }

    public int getRuestung() {
        return this.ruestung;
    }
}
