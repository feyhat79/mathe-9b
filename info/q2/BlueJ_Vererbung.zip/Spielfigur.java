/**
 * Oberklasse Spielfigur
 * 
 * Modelliert eine allgemeine Figur in einem Rollenspiel.
 * Dient als gemeinsame Basisklasse fuer spezialisierte Figuren (z. B. Krieger, Magier).
 * 
 * @author Informatik Q2
 * @version Schuljahr 2026/27
 */
public class Spielfigur {
    // Gemeinsame Attribute aller Spielfiguren
    // protected erlaubt den direkten Zugriff in vererbenden Unterklassen
    protected String name;
    protected int lebenspunkte;
    protected int basisSchaden;

    /**
     * Konstruktor zur Initialisierung der Grundwerte jeder Spielfigur.
     * 
     * @param pName          Name der Figur
     * @param pLebenspunkte  Start-Lebenspunkte (HP)
     * @param pBasisSchaden  Standard-Schadenswert bei Angriffen
     */
    public Spielfigur(String pName, int pLebenspunkte, int pBasisSchaden) {
        this.name = pName;
        this.lebenspunkte = Math.max(0, pLebenspunkte);
        this.basisSchaden = Math.max(0, pBasisSchaden);
    }

    /**
     * Zieht der Spielfigur Schaden ab.
     * Stellt sicher, dass die Lebenspunkte nicht unter 0 fallen.
     * 
     * @param pSchaden Zugefuegter Schadensbetrag
     */
    public void nimmSchaden(int pSchaden) {
        if (pSchaden > 0) {
            this.lebenspunkte -= pSchaden;
            if (this.lebenspunkte < 0) {
                this.lebenspunkte = 0;
            }
            System.out.println("[" + this.name + "] erleidet " + pSchaden + " Schaden. Verbleibende LP: " + this.lebenspunkte);
            if (this.lebenspunkte == 0) {
                System.out.println(">>> [" + this.name + "] ist kampfunfaehig!");
            }
        }
    }

    /**
     * Heilt die Spielfigur um den angegebenen Betrag.
     * 
     * @param pPunkte Heilungspunkte
     */
    public void heilen(int pPunkte) {
        if (pPunkte > 0 && istLebendig()) {
            this.lebenspunkte += pPunkte;
            System.out.println("[" + this.name + "] wird um " + pPunkte + " geheilt. Aktuelle LP: " + this.lebenspunkte);
        }
    }

    /**
     * Standard-Angriff auf ein anderes Ziel.
     * 
     * @param pZiel Die anzugreifende Spielfigur
     */
    public void angreifen(Spielfigur pZiel) {
        if (pZiel == null) {
            System.out.println("Kein gueltiges Ziel angegeben!");
        } else if (!istLebendig()) {
            System.out.println("[" + this.name + "] kann nicht angreifen, da kampfunfaehig.");
        } else {
            System.out.println("[" + this.name + "] fuehrt Basisangriff auf [" + pZiel.getName() + "] aus (" + this.basisSchaden + " Schaden).");
            pZiel.nimmSchaden(this.basisSchaden);
        }
    }

    /**
     * BEISPIEL FUER METHODEN-UEBERLADUNG (Overloading):
     * Gleicher Methodenname 'angreifen', aber andere Parameterliste!
     * Hier: Zusätzlicher Bonus-Schaden (z. B. durch Waffeneinsatz oder kritischen Treffer).
     * 
     * @param pZiel         Die anzugreifende Spielfigur
     * @param pBonusSchaden Zusaetzlicher Extraschaden
     */
    public void angreifen(Spielfigur pZiel, int pBonusSchaden) {
        if (pZiel == null) {
            System.out.println("Kein gueltiges Ziel angegeben!");
        } else if (!istLebendig()) {
            System.out.println("[" + this.name + "] kann nicht angreifen, da kampfunfaehig.");
        } else {
            int gesamtSchaden = this.basisSchaden + Math.max(0, pBonusSchaden);
            System.out.println("[" + this.name + "] fuehrt Kraftangriff auf [" + pZiel.getName() + "] aus! (" + gesamtSchaden + " Schaden).");
            pZiel.nimmSchaden(gesamtSchaden);
        }
    }

    /**
     * Prueft, ob die Figur noch spielfaehig ist.
     * 
     * @return true, wenn noch Lebenspunkte vorhanden sind
     */
    public boolean istLebendig() {
        return this.lebenspunkte > 0;
    }

    // Getter-Methoden
    public String getName() {
        return this.name;
    }

    public int getLebenspunkte() {
        return this.lebenspunkte;
    }

    public int getBasisSchaden() {
        return this.basisSchaden;
    }

    /**
     * Gibt eine Uebersicht ueber den aktuellen Status der Figur aus.
     */
    public void statusAusgeben() {
        System.out.println("--- STATUS: " + this.name + " ---");
        System.out.println("Lebenspunkte: " + this.lebenspunkte);
        System.out.println("Basisschaden: " + this.basisSchaden);
    }
}
