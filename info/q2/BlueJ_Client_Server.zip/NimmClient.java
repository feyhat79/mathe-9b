/**
 * Klasse NimmClient
 * 
 * Fertiggestellter Netzwerk-Client fuer das Nimm-Spiel.
 * Verbindet sich mit dem NimmServer und ermoeglicht das Absenden von Spielzuegen.
 * 
 * SPIELREGELN:
 * - 2 Spieler spielen gegeneinander.
 * - Startbestand: 17 Objekte.
 * - In jedem Zug duerfen 1, 2 oder 3 Objekte genommen werden.
 * - Wer das LETZTE Objekt nehmen muss, hat VERLOREN.
 * 
 * BEDIENUNG IN BLUEJ:
 * 1. Objekt von NimmClient erzeugen (Standard verbindet mit 127.0.0.1:50000).
 * 2. Warten, bis der Server meldet: "DU BIST DRAN!".
 * 3. Methode 'ziehe(int pAnzahl)' aufrufen (z. B. 'ziehe(2)').
 * 
 * @author Informatik Q2
 * @version Schuljahr 2026/27
 */
public class NimmClient extends Client {

    /**
     * Verbindet sich mit einem NimmServer auf der angegebenen IP und dem Port.
     * 
     * @param pServerIP   IP-Adresse des Servers (z. B. "127.0.0.1" oder Schulnetz-IP)
     * @param pServerPort Portnummer (z. B. 50000)
     */
    public NimmClient(String pServerIP, int pServerPort) {
        super(pServerIP, pServerPort);
        
        if (isConnected()) {
            System.out.println("==================================================");
            System.out.println("  NIMM-CLIENT ERFOLGREICH VERBUNDEN!");
            System.out.println("  Server: " + pServerIP + ":" + pServerPort);
            System.out.println("  Warte auf Zuteilung durch den Server...");
            System.out.println("==================================================");
        } else {
            System.err.println("Fehler: Verbindung zu " + pServerIP + ":" + pServerPort + " fehlgeschlagen.");
            System.err.println("Bitte pruefen: Laeuft der NimmServer bereits?");
        }
    }

    /**
     * Bequemer Standard-Konstruktor fuer den lokalen Test (localhost, Port 50000).
     */
    public NimmClient() {
        this("127.0.0.1", 50000);
    }

    /**
     * Führt einen Spielzug aus.
     * Prueft zunaechst die lokalen Spielregeln (nur 1 bis 3 Objekte zulaessig)
     * und sendet bei Gueltigkeit den Befehl "NIMM <anzahl>" an den Server.
     * 
     * @param pAnzahl Die Anzahl der zu nehmenden Objekte (1, 2 oder 3)
     */
    public void ziehe(int pAnzahl) {
        if (!isConnected()) {
            System.err.println("[FEHLER] Nicht mit dem Server verbunden!");
            return;
        }

        // Vorab-Pruefung der zulaessigen Zugmenge
        if (pAnzahl < 1 || pAnzahl > 3) {
            System.err.println("[REGEL-FEHLER] Du darfst nur 1, 2 oder 3 Objekte nehmen!");
            return;
        }

        // Protokoll-Befehl absenden
        System.out.println("-> [MEIN ZUG]: Ich nehme " + pAnzahl + " Objekt(e)...");
        send("NIMM " + pAnzahl);
    }

    /**
     * Hilfsmethode zum manuellen Senden von beliebigen Texten/Befehlen.
     * 
     * @param pText Der an den Server zu sendende Text
     */
    public void sendeNachricht(String pText) {
        System.out.println("-> [SENDE]: " + pText);
        send(pText);
    }

    /**
     * Verarbeitet alle vom Server empfangenen Nachrichten gemaess Protokoll.
     * Wird automatisch vom Hintergrund-Thread aufgerufen.
     * 
     * @param pMessage Die empfangene Protokoll-Nachricht
     */
    @Override
    public void processMessage(String pMessage) {
        if (pMessage == null || pMessage.isEmpty()) {
            return;
        }

        String[] teile = pMessage.split(" ");
        String befehl = teile[0];

        switch (befehl) {
            case "START":
                // Format: START <spielerNummer>
                String spielerNr = (teile.length > 1) ? teile[1] : "?";
                System.out.println("==================================================");
                System.out.println("  DAS SPIEL BEGINNT!");
                System.out.println("  Du bist SPIELER " + spielerNr);
                System.out.println("==================================================");
                break;

            case "DRAN":
                // Format: DRAN <restObjekte>
                String restDran = (teile.length > 1) ? teile[1] : "?";
                System.out.println(">>> [DU BIST AM ZUG!]");
                System.out.println("    Es verbleiben noch " + restDran + " Objekt(e) auf dem Tisch.");
                System.out.println("    Rufe jetzt 'ziehe(1)', 'ziehe(2)' oder 'ziehe(3)' auf!");
                break;

            case "WARTEN":
                // Format: WARTEN <restObjekte>
                String restWarten = (teile.length > 1) ? teile[1] : "?";
                System.out.println("... [BITTE WARTEN]");
                System.out.println("    Der Gegenspieler ist am Zug. (Verbleibend: " + restWarten + ")");
                break;

            case "GEWONNEN":
                System.out.println("**************************************************");
                System.out.println("  SIEG! Du hast das Nimm-Spiel GEWONNEN!");
                System.out.println("  Der Gegenspieler musste das letzte Objekt nehmen.");
                System.out.println("**************************************************");
                break;

            case "VERLOREN":
                System.out.println("**************************************************");
                System.out.println("  NIEDERLAGE! Du hast das letzte Objekt genommen.");
                System.out.println("  Du hast dieses Spiel leider VERLOREN.");
                System.out.println("**************************************************");
                break;

            case "FEHLER":
                // Format: FEHLER <Nachrichtentext>
                String fehlerText = pMessage.substring(befehl.length()).trim();
                System.err.println("[SERVER-FEHLER]: " + fehlerText);
                break;

            case "INFO":
                // Format: INFO <Nachrichtentext>
                String infoText = pMessage.substring(befehl.length()).trim();
                System.out.println("[INFO]: " + infoText);
                break;

            default:
                // Unbekannte oder rohe Nachricht
                System.out.println("[SERVER]: " + pMessage);
                break;
        }
    }
}
