import java.net.*;
import java.io.*;
import java.util.Vector;

/**
 * Abstrakte Klasse Server
 * 
 * Abitur-Vorgabeklasse (NRW) fuer Rechnernetze.
 * 
 * Kapselt das Verhalten eines TCP-Netzwerk-Servers als BLACKBOX.
 * 
 * WARUM IST DIESE KLASSE ABSTRAKT?
 * Der Server uebernimmt das Oeffnen des ServerSockets auf einem Port,
 * das kontinuierliche Warten auf neue Clients (ServerSocket.accept())
 * sowie die parallele Verwaltung beliebig vieler verbundener Clients ueber Threads.
 * 
 * Der Server weiss jedoch NICHT, welche Spiel- oder Chat-Logik ihr programmieren wollt!
 * 
 * Daher definiert die Klasse DREI ABSTRAKTE METHODEN:
 * 1. processNewConnection(pClientIP, pClientPort)     -> Neuer Teilnehmer da!
 * 2. processMessage(pClientIP, pClientPort, pMessage) -> Nachricht empfangen!
 * 3. processClosingConnection(pClientIP, pClientPort) -> Teilnehmer hat beendet!
 * 
 * Jede konkrete Server-Unterklasse (z. B. 'EchoServer extends Server') MUSS
 * diese drei Methoden ueberschreiben (@Override).
 * 
 * @author Qualitaets- und UnterstuetzungsAgentur - Landesinstitut fuer Schule (QUA-LiS NRW)
 * @version Schuljahr 2026/27 (Kommentierte Schulausgabe)
 */
public abstract class Server {

    private NewConnectionHandler connectionHandler;
    private Vector<ServerConnection> connectionList;

    /**
     * Eigener Thread fuer jeden verbundenen Client.
     * Empfaengt asynchron Nachrichten dieses spezifischen Clients.
     */
    private class ServerConnection extends Thread {
        private Connection connection;
        private boolean isRunning;

        private ServerConnection(Socket pSocket) {
            this.connection = new Connection(pSocket);
            this.isRunning = true;
        }

        @Override
        public void run() {
            while (this.isRunning) {
                String message = this.connection.receive();
                if (message != null) {
                    // KLINGEL-EFFEKT: Nachricht an die abstrakte Server-Methode melden!
                    processMessage(this.connection.getRemoteIP(), this.connection.getRemotePort(), message);
                } else {
                    // Client hat die Verbindung getrennt
                    this.isRunning = false;
                    closeConnection(this.connection.getRemoteIP(), this.connection.getRemotePort());
                }
            }
        }

        private void send(String pMessage) {
            this.connection.send(pMessage);
        }

        private void close() {
            this.isRunning = false;
            this.connection.close();
        }
    }

    /**
     * Listener-Thread: Wartet auf einem Port kontinuierlich auf neue Clients.
     */
    private class NewConnectionHandler extends Thread {
        private ServerSocket serverSocket;
        private boolean isRunning;

        private NewConnectionHandler(int pPort) {
            try {
                this.serverSocket = new ServerSocket(pPort);
                this.isRunning = true;
                this.start();
            } catch (Exception e) {
                System.err.println("[Server-Fehler] Konnte Port " + pPort + " nicht oeffnen: " + e.getMessage());
                this.serverSocket = null;
                this.isRunning = false;
            }
        }

        @Override
        public void run() {
            while (this.isRunning) {
                try {
                    // Wartet blockierend, bis ein Client 'anklopft'
                    Socket clientSocket = this.serverSocket.accept();
                    ServerConnection sc = new ServerConnection(clientSocket);
                    sc.start();
                    connectionList.add(sc);

                    // KLINGEL-EFFEKT: Neuen Client an die Unterklasse melden!
                    processNewConnection(sc.connection.getRemoteIP(), sc.connection.getRemotePort());
                } catch (Exception e) {
                    // Tritt auf, wenn der Server mit close() beendet wird
                }
            }
        }

        private void close() {
            this.isRunning = false;
            try {
                if (this.serverSocket != null) {
                    this.serverSocket.close();
                }
            } catch (Exception e) {
            }
        }
    }

    /**
     * Konstruktor: Startet den Server auf der angegebenen Portnummer.
     * 
     * @param pPort Portnummer (z. B. 50000, Werte von 1024 bis 65535 sind frei nutzbar)
     */
    public Server(int pPort) {
        this.connectionList = new Vector<ServerConnection>();
        this.connectionHandler = new NewConnectionHandler(pPort);
    }

    /**
     * Prueft, ob der Server betriebsbereit ist und auf Clients wartet.
     * 
     * @return true, falls der Port geoeffnet werden konnte
     */
    public boolean isOpen() {
        return (this.connectionHandler != null && this.connectionHandler.isRunning);
    }

    /**
     * Prueft, ob zu einer bestimmten IP und Portnummer eine aktive Verbindung besteht.
     */
    public boolean isConnectedTo(String pClientIP, int pClientPort) {
        for (ServerConnection sc : this.connectionList) {
            if (sc.connection.getRemoteIP().equals(pClientIP) && sc.connection.getRemotePort() == pClientPort) {
                return true;
            }
        }
        return false;
    }

    /**
     * Sendet eine Nachricht gezielt an EINEN bestimmten Client.
     * 
     * @param pClientIP   IP-Adresse des Empfaengers
     * @param pClientPort Portnummer des Empfaengers
     * @param pMessage    Die zu sendende Textzeile
     */
    public void send(String pClientIP, int pClientPort, String pMessage) {
        for (ServerConnection sc : this.connectionList) {
            if (sc.connection.getRemoteIP().equals(pClientIP) && sc.connection.getRemotePort() == pClientPort) {
                sc.send(pMessage);
                return;
            }
        }
    }

    /**
     * BROADCAST: Sendet eine Nachricht an ALLE aktuell verbundenen Clients.
     * Ideal fuer Chats oder Spiel-Ankuendigungen!
     * 
     * @param pMessage Die Nachricht an alle
     */
    public void sendToAll(String pMessage) {
        for (ServerConnection sc : this.connectionList) {
            sc.send(pMessage);
        }
    }

    /**
     * Trennt die Verbindung zu einem bestimmten Client gezielt.
     */
    public synchronized void closeConnection(String pClientIP, int pClientPort) {
        for (int i = 0; i < this.connectionList.size(); i++) {
            ServerConnection sc = this.connectionList.get(i);
            if (sc.connection.getRemoteIP().equals(pClientIP) && sc.connection.getRemotePort() == pClientPort) {
                this.connectionList.remove(i);
                sc.close();
                processClosingConnection(pClientIP, pClientPort);
                return;
            }
        }
    }

    /**
     * Beendet den gesamten Server und trennt alle Verbindungen.
     */
    public void close() {
        if (this.connectionHandler != null) {
            this.connectionHandler.close();
        }
        for (ServerConnection sc : this.connectionList) {
            sc.close();
        }
        this.connectionList.clear();
    }

    // =========================================================================
    // DREI ABSTRAKTE METHODEN - DER VERTRAG FUER DIE UNTERKLASSE
    // =========================================================================

    /**
     * Wird automatisch aufgerufen, sobald sich ein neuer Client verbindet.
     * 
     * @param pClientIP   IP-Adresse des neuen Clients
     * @param pClientPort Port des neuen Clients
     */
    public abstract void processNewConnection(String pClientIP, int pClientPort);

    /**
     * Wird automatisch aufgerufen, sobald ein Client eine Nachricht sendet.
     * 
     * @param pClientIP   IP-Adresse des Absenders
     * @param pClientPort Port des Absenders
     * @param pMessage    Der gesendete Text
     */
    public abstract void processMessage(String pClientIP, int pClientPort, String pMessage);

    /**
     * Wird automatisch aufgerufen, wenn ein Client die Verbindung trennt.
     * 
     * @param pClientIP   IP-Adresse des scheidenden Clients
     * @param pClientPort Port des scheidenden Clients
     */
    public abstract void processClosingConnection(String pClientIP, int pClientPort);
}
