import java.net.*;
import java.io.*;

/**
 * Klasse Connection
 * 
 * Abitur-Vorgabeklasse (NRW) fuer Rechnernetze.
 * 
 * Kapselt eine einzelne TCP-Verbindung (Socket) zwischen zwei Rechnern
 * sowie die zugehoerigen Datenstroeme (Streams).
 * 
 * DIESE KLASSE IST EINE BLACKBOX:
 * Sie uebernimmt das technische Senden und Empfangen von Bytes ueber TCP/IP.
 * Als Entwickler rufen wir lediglich 'send(text)' und 'receive()' auf.
 * 
 * @author Qualitaets- und UnterstuetzungsAgentur - Landesinstitut fuer Schule (QUA-LiS NRW)
 * @version Schuljahr 2026/27 (Kommentierte Schulausgabe)
 */
public class Connection {

    private Socket socket;
    private BufferedReader fromServer;
    private PrintWriter toServer;

    /**
     * Erstellt eine neue aktive Verbindung (Client-Sicht) zu einem Server.
     * 
     * @param pServerIP   Die IP-Adresse des Zielservers (z. B. "127.0.0.1" fuer localhost)
     * @param pServerPort Die Portnummer, auf der der Zielserver lauscht (z. B. 50000)
     */
    public Connection(String pServerIP, int pServerPort) {
        try {
            this.socket = new Socket(pServerIP, pServerPort);
            this.fromServer = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
            this.toServer = new PrintWriter(this.socket.getOutputStream(), true); // true = autoFlush
        } catch (Exception e) {
            System.err.println("[Connection-Fehler] Verbindung zu " + pServerIP + ":" + pServerPort + " fehlgeschlagen: " + e.getMessage());
            this.socket = null;
            this.toServer = null;
            this.fromServer = null;
        }
    }

    /**
     * Erstellt eine Verbindung aus einem bereits geoeffneten Socket (Server-Sicht).
     * 
     * @param pSocket Der von ServerSocket.accept() angenommene Socket
     */
    public Connection(Socket pSocket) {
        if (pSocket != null) {
            this.socket = pSocket;
            try {
                this.fromServer = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
                this.toServer = new PrintWriter(this.socket.getOutputStream(), true);
            } catch (Exception e) {
                System.err.println("[Connection-Fehler] Stream-Initialisierung fehlgeschlagen: " + e.getMessage());
                this.fromServer = null;
                this.toServer = null;
            }
        }
    }

    /**
     * Wartet auf eine eingehende Textzeile und liest diese aus.
     * 
     * ACHTUNG: Diese Methode blockiert, bis eine neue Zeile (mit '\n') eintrifft!
     * Daher wird sie in Client und Server stets in einem separaten Thread ausgefuehrt.
     * 
     * @return Der empfangene Text oder null bei Verbindungsabbruch
     */
    public String receive() {
        if (this.fromServer != null) {
            try {
                return this.fromServer.readLine();
            } catch (IOException e) {
                // Verbindungsabbruch oder Socket geschlossen
            }
        }
        return null;
    }

    /**
     * Sendet eine Textzeile an den Verbindungspartner.
     * Schliesst die Nachricht automatisch mit einem Zeilenumbruch ab.
     * 
     * @param pMessage Die zu sendende Nachricht
     */
    public void send(String pMessage) {
        if (this.toServer != null && pMessage != null) {
            this.toServer.println(pMessage);
        }
    }

    /**
     * Schliesst die Verbindung und gibt Systemressourcen frei.
     */
    public void close() {
        if (this.socket != null) {
            try {
                this.socket.close();
            } catch (IOException e) {
                // Ignorieren beim Beenden
            }
        }
    }

    /**
     * Liefert die IP-Adresse des fernen Verbindungspartners.
     * 
     * @return IP-Adresse als String (z. B. "127.0.0.1") oder null
     */
    public String getRemoteIP() {
        if (this.socket != null && this.socket.getInetAddress() != null) {
            return this.socket.getInetAddress().getHostAddress();
        }
        return null;
    }

    /**
     * Liefert die Portnummer des fernen Verbindungspartners.
     * 
     * @return Portnummer oder 0
     */
    public int getRemotePort() {
        if (this.socket != null) {
            return this.socket.getPort();
        }
        return 0;
    }
}
