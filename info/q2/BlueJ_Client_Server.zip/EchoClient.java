/**
 * Klasse EchoClient
 * 
 * Erste konkrete Unterklasse von Client.
 * Demonstriert das Prinzip von 'extends Client' und das Ueberschreiben
 * der abstrakten Methode 'processMessage(...)'.
 * 
 * @author Informatik Q2
 * @version Schuljahr 2026/27
 */
public class EchoClient extends Client {

    /**
     * Baut eine Verbindung zum Server auf.
     * 
     * @param pServerIP   Ziel-IP (z. B. "127.0.0.1" fuer lokalen Test oder Schul-IP)
     * @param pServerPort Ziel-Port (z. B. 50000)
     */
    public EchoClient(String pServerIP, int pServerPort) {
        // Aufruf des Konstruktors der abstrakten Oberklasse Client
        super(pServerIP, pServerPort);
        
        if (isConnected()) {
            System.out.println("==================================================");
            System.out.println("  VERBUNDEN MIT SERVER: " + pServerIP + ":" + pServerPort);
            System.out.println("  Nutze 'sendeNachricht(\"...\")' zum Abschicken!");
            System.out.println("==================================================");
        } else {
            System.err.println("Fehler: Verbindung zu " + pServerIP + ":" + pServerPort + " fehlgeschlagen.");
            System.err.println("Laeuft der Server bereits?");
        }
    }

    /**
     * Bequemer Konstruktor fuer den lokalen Test (localhost, Port 50000).
     */
    public EchoClient() {
        this("127.0.0.1", 50000);
    }

    /**
     * Eigene Hilfsmethode, um bequem aus BlueJ Text abzusenden.
     * Ruft intern die geerbte Methode 'send(...)' auf.
     * 
     * @param pText Der abzuschickende Text
     */
    public void sendeNachricht(String pText) {
        System.out.println("-> [ICH SENDE]: " + pText);
        send(pText);
    }

    /**
     * DIE ABSTRAKTE METHODE DER OBERKLASSE:
     * 
     * Wird automatisch vom Hintergrund-Thread aufgerufen,
     * sobald eine Zeile vom Server bei uns ankommt.
     * 
     * @param pMessage Die empfangene Antwort des Servers
     */
    @Override
    public void processMessage(String pMessage) {
        System.out.println("<- [VOM SERVER EMPFANGEN]: " + pMessage);
    }
}
