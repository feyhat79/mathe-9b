/**
 * Klasse EchoServer
 * 
 * Erste konkrete Unterklasse von Server.
 * Demonstriert das Prinzip von 'extends Server' und das Ueberschreiben
 * der drei abstrakten Methoden.
 * 
 * VERHALTEN:
 * Antwortet jedem Client mit "Echo: <Nachricht>".
 * 
 * @author Informatik Q2
 * @version Schuljahr 2026/27
 */
public class EchoServer extends Server { 

    /**
     * Startet den EchoServer auf dem angegebenen Port.
     * 
     * @param pPort Portnummer (z. B. 50000)
     */
    public EchoServer(int pPort) {
        // Aufruf des Konstruktors der abstrakten Oberklasse Server
        super(pPort);
        
        if (isOpen()) {
            System.out.println("==================================================");
            System.out.println("  ECHO-SERVER GESTARTET AUF PORT " + pPort);
            System.out.println("  Wartet auf eingehende Verbindungen...");
            System.out.println("==================================================");
        } else {
            System.err.println("Fehler: Server konnte nicht gestartet werden. Port blockiert?");
        }
    }

    /**
     * Bequemer Standard-Konstruktor fuer den Schnellstart in BlueJ.
     * Nutzt automatisch Port 50000.
     */
    public EchoServer() {
        this(50000);
    }

    /**
     * WIRD AUTOMATISCH AUFGERUFEN, wenn ein neuer Client anklopft.
     */
    @Override
    public void processNewConnection(String pClientIP, int pClientPort) {
        System.out.println(">>> [SERVER] Neuer Teilnehmer verbunden: " + pClientIP + " (Port " + pClientPort + ")");
        // Freundliche Begruessung an den neuen Client senden
        send(pClientIP, pClientPort, "WILLKOMMEN: Du bist mit dem EchoServer verbunden!");
    }

    /**
     * WIRD AUTOMATISCH AUFGERUFEN, wenn ein Client Text schickt.
     * Hier sitzt die eigentliche Antwort-Logik!
     */
    @Override
    public void processMessage(String pClientIP, int pClientPort, String pMessage) {
        System.out.println("[SERVER] Empfangen von " + pClientIP + ": " + pMessage);

        // Das Echo zurueck an genau diesen Absender senden
        String antwort = "Echo: " + pMessage;
        send(pClientIP, pClientPort, antwort);
    }

    /**
     * WIRD AUTOMATISCH AUFGERUFEN, wenn ein Client auflegt.
     */
    @Override
    public void processClosingConnection(String pClientIP, int pClientPort) {
        System.out.println("<<< [SERVER] Verbindung beendet durch: " + pClientIP);
    }
}
