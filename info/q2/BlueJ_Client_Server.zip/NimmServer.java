/**
 * Klasse NimmServer
 * 
 * Didaktisches Geruest fuer den Spielserver des Nimm-Spiels.
 * Erbt von der abstrakten Oberklasse 'Server' (Abiturklasse NRW).
 * 
 * SPIELREGELN:
 * - 2 Spieler spielen rundenbasiert gegeneinander.
 * - Startbestand: 17 Objekte auf dem Tisch.
 * - In jedem Zug duerfen 1, 2 oder 3 Objekte genommen werden.
 * - Wer das LETZTE Objekt nehmen muss, hat VERLOREN (Misere-Regel).
 * 
 * @author Informatik Q2
 * @version Schuljahr 2026/27
 */
public class NimmServer extends Server {

    // =========================================================================
    // ATTRIBUTE DES SERVERS (Spielzustand & Teilnehmer)
    // =========================================================================

    /** Aktuelle Anzahl der verbleibenden Objekte (Standard zu Beginn: 17) */
    private int anzahlObjekte;

    /** Gibt an, ob gerade eine Runde laeuft */
    private boolean spielAktiv;

    /** Welcher Spieler gerade am Zug ist (1 oder 2) */
    private int aktiverSpieler;

    /** Verbindungsdaten von Spieler 1 */
    private String spieler1IP;
    private int spieler1Port;

    /** Verbindungsdaten von Spieler 2 */
    private String spieler2IP;
    private int spieler2Port;

    // =========================================================================
    // KONSTRUKTOREN
    // =========================================================================

    /**
     * Startet den NimmServer auf einem bestimmten Port.
     * 
     * @param pPort Der Port, auf dem der Server lauscht (z. B. 50000)
     */
    public NimmServer(int pPort) {
        super(pPort);
        zuruecksetzen();

        if (isOpen()) {
            System.out.println("==================================================");
            System.out.println("  NIMM-SERVER ERFOLGREICH GESTARTET AUF PORT " + pPort);
            System.out.println("  Warte auf 2 Spieler...");
            System.out.println("==================================================");
        } else {
            System.err.println("Fehler: Server konnte nicht geoeffnet werden. Port bereits belegt?");
        }
    }

    /**
     * Bequemer Standard-Konstruktor fuer den Schnellstart in BlueJ (Port 50000).
     */
    public NimmServer() {
        this(50000);
    }

    // =========================================================================
    // HILFSMETHODEN ZUR VERBINDUNGS- & SPIELVERWALTUNG
    // =========================================================================

    /**
     * Setzt das Spiel komplett auf den Anfangszustand zurueck.
     */
    public void zuruecksetzen() {
        this.anzahlObjekte = 17;
        this.spielAktiv = false;
        this.aktiverSpieler = 1;

        this.spieler1IP = null;
        this.spieler1Port = -1;
        this.spieler2IP = null;
        this.spieler2Port = -1;

        System.out.println("[SERVER-STATUS] Spiel zurueckgesetzt auf 17 Objekte.");
    }

    /**
     * Prueft, ob die IP und der Port zu Spieler 1 gehoeren.
     */
    public boolean istSpieler1(String pClientIP, int pClientPort) {
        return pClientIP.equals(this.spieler1IP) && pClientPort == this.spieler1Port;
    }

    /**
     * Prueft, ob die IP und der Port zu Spieler 2 gehoeren.
     */
    public boolean istSpieler2(String pClientIP, int pClientPort) {
        return pClientIP.equals(this.spieler2IP) && pClientPort == this.spieler2Port;
    }

    /**
     * Sendet eine Protokoll-Nachricht gezielt an Spieler 1 oder Spieler 2.
     * 
     * @param pSpielerNr  1 oder 2
     * @param pNachricht  Die zu sendende Nachricht
     */
    public void sendeAnSpieler(int pSpielerNr, String pNachricht) {
        if (pSpielerNr == 1 && spieler1IP != null) {
            send(spieler1IP, spieler1Port, pNachricht);
        } else if (pSpielerNr == 2 && spieler2IP != null) {
            send(spieler2IP, spieler2Port, pNachricht);
        }
    }

    /**
     * Sendet eine Protokoll-Nachricht gleichzeitig an beide Spieler (Broadcast).
     * 
     * @param pNachricht Die Nachricht fuer beide Clients
     */
    public void sendeAnBeide(String pNachricht) {
        sendeAnSpieler(1, pNachricht);
        sendeAnSpieler(2, pNachricht);
    }

    /**
     * Startet das Duell, sobald beide Spieler verbunden sind.
     */
    public void starteSpiel() {
        this.anzahlObjekte = 17;
        this.spielAktiv = true;
        this.aktiverSpieler = 1;

        System.out.println("==================================================");
        System.out.println("  SPIEL GESTARTET! 17 Objekte auf dem Tisch.");
        System.out.println("  Spieler 1: " + spieler1IP + ":" + spieler1Port);
        System.out.println("  Spieler 2: " + spieler2IP + ":" + spieler2Port);
        System.out.println("==================================================");

        // Beide Clients ueber Rollen informieren
        sendeAnSpieler(1, "START 1");
        sendeAnSpieler(2, "START 2");

        // Spieler 1 darf anfangen, Spieler 2 muss warten
        sendeAnSpieler(1, "DRAN " + anzahlObjekte);
        sendeAnSpieler(2, "WARTEN " + anzahlObjekte);
    }

    // =========================================================================
    // MEILENSTEIN 1: VERBINDUNGSAUFBAU (processNewConnection)
    // =========================================================================

    /**
     * Wird automatisch aufgerufen, wenn sich ein neuer Client verbindet.
     * 
     * AUFGABE 1:
     * - Pruefe, ob Platz fuer Spieler 1 frei ist (spieler1IP == null).
     * - Falls ja: Speichere IP und Port fuer Spieler 1 und informiere ihn ("INFO ...").
     * - Falls nein: Pruefe, ob Platz fuer Spieler 2 frei ist (spieler2IP == null).
     * - Falls ja: Speichere IP und Port fuer Spieler 2 und starte das Spiel!
     * - Falls beide Plaetze bereits besetzt sind: Weise den Client ab.
     */
    @Override
    public void processNewConnection(String pClientIP, int pClientPort) {
        System.out.println(">>> Neuer Client klopft an: " + pClientIP + ":" + pClientPort);

        if (spieler1IP == null) {
            // Spieler 1 registrieren
            spieler1IP = pClientIP;
            spieler1Port = pClientPort;
            System.out.println("[SERVER] Spieler 1 registriert!");
            send(pClientIP, pClientPort, "INFO Du bist Spieler 1. Warte auf Gegenspieler...");
        } else if (spieler2IP == null) {
            // Spieler 2 registrieren
            spieler2IP = pClientIP;
            spieler2Port = pClientPort;
            System.out.println("[SERVER] Spieler 2 registriert!");
            send(pClientIP, pClientPort, "INFO Du bist Spieler 2. Spiel startet sofort!");
            
            // Beide Spieler sind da -> Spiel starten!
            starteSpiel();
        } else {
            // Bereits 2 Spieler vorhanden -> Dritten Client ablehnen
            System.out.println("[SERVER] Verbindung abgewiesen: Spiel ist bereits voll.");
            send(pClientIP, pClientPort, "FEHLER Das Spiel ist bereits voll (2/2 Spieler).");
            closeConnection(pClientIP, pClientPort);
        }
    }

    // =========================================================================
    // MEILENSTEIN 2 & 3: NACHRICHTEN-PARSER & SPIELZUG (processMessage)
    // =========================================================================

    /**
     * Wird automatisch aufgerufen, sobald ein Client eine Nachricht schickt.
     * 
     * AUFGABE 2 & 3:
     * - Pruefen, ob das Spiel ueberhaupt aktiv ist.
     * - Pruefen, welcher Spieler gesendet hat (istSpieler1 / istSpieler2).
     * - Pruefen, ob dieser Spieler gerade am Zug ist!
     * - Pruefen, ob die Nachricht mit "NIMM " beginnt.
     * - Die Zahl parsen und fuehreZugAus(...) aufrufen.
     */
    @Override
    public void processMessage(String pClientIP, int pClientPort, String pMessage) {
        System.out.println("[EMPFANGEN von " + pClientIP + ":" + pClientPort + "]: " + pMessage);

        if (!spielAktiv) {
            send(pClientIP, pClientPort, "FEHLER Kein Spiel aktiv oder noch nicht genuegend Spieler.");
            return;
        }

        // Ermitteln, wer gesendet hat (1 oder 2)
        int absenderNummer = 0;
        if (istSpieler1(pClientIP, pClientPort)) {
            absenderNummer = 1;
        } else if (istSpieler2(pClientIP, pClientPort)) {
            absenderNummer = 2;
        } else {
            send(pClientIP, pClientPort, "FEHLER Unbekannter Absender.");
            return;
        }

        // Pruefung: Ist dieser Absender wirklich am Zug?
        if (absenderNummer != aktiverSpieler) {
            send(pClientIP, pClientPort, "FEHLER Du bist nicht an der Reihe! Bitte warten.");
            return;
        }

        // Protokoll-Befehl pruefen
        if (pMessage.startsWith("NIMM ")) {
            try {
                String anzahlText = pMessage.substring(5).trim();
                int anzahl = Integer.parseInt(anzahlText);

                // Den Zug validieren und ausfuehren
                fuehreZugAus(absenderNummer, anzahl);

            } catch (NumberFormatException e) {
                send(pClientIP, pClientPort, "FEHLER Ungueltiges Zahlenformat nach NIMM.");
            }
        } else {
            send(pClientIP, pClientPort, "FEHLER Unbekannter Befehl. Erlaubt ist: NIMM <anzahl>");
        }
    }

    /**
     * Fuehrt den eigentlichen Spielzug gemaess den Nimm-Regeln aus.
     * 
     * REGELN:
     * 1. Erlaubte Zuganzahl: 1, 2 oder 3 Objekte.
     * 2. Man darf nicht mehr Objekte nehmen, als noch vorhanden sind.
     * 3. MISERE-REGEL: Wer das letzte Objekt nehmen muss (also anzahlObjekte <= 0),
     *    hat das Spiel VERLOREN!
     */
    public void fuehreZugAus(int pSpielerNr, int pAnzahl) {
        // Regelpruefung 1: Nur 1, 2 oder 3 erlaubt
        if (pAnzahl < 1 || pAnzahl > 3) {
            sendeAnSpieler(pSpielerNr, "FEHLER Du darfst nur 1, 2 oder 3 Objekte nehmen!");
            sendeAnSpieler(pSpielerNr, "DRAN " + anzahlObjekte);
            return;
        }

        // Regelpruefung 2: Nicht mehr nehmen als noch da ist
        if (pAnzahl > anzahlObjekte) {
            sendeAnSpieler(pSpielerNr, "FEHLER Es liegen nur noch " + anzahlObjekte + " Objekte auf dem Tisch!");
            sendeAnSpieler(pSpielerNr, "DRAN " + anzahlObjekte);
            return;
        }

        // Objekte abziehen
        anzahlObjekte -= pAnzahl;
        System.out.println("[ZUG] Spieler " + pSpielerNr + " nimmt " + pAnzahl + " Objekt(e). Rest: " + anzahlObjekte);

        // MEILENSTEIN 4: ENDBEDINGUNG (Misere-Regel)
        if (anzahlObjekte <= 0) {
            // Wer das letzte Objekt genommen hat, hat VERLOREN!
            int gegenspielerNr = (pSpielerNr == 1) ? 2 : 1;

            System.out.println("**************************************************");
            System.out.println("  SPIEL VORBEI!");
            System.out.println("  Spieler " + pSpielerNr + " hat das letzte Objekt genommen -> VERLOREN!");
            System.out.println("  Spieler " + gegenspielerNr + " hat GEWONNEN!");
            System.out.println("**************************************************");

            sendeAnSpieler(pSpielerNr, "VERLOREN");
            sendeAnSpieler(gegenspielerNr, "GEWONNEN");

            spielAktiv = false;
        } else {
            // Das Spiel geht weiter: Rollen tauschen!
            aktiverSpieler = (aktiverSpieler == 1) ? 2 : 1;

            int wartenderSpieler = (aktiverSpieler == 1) ? 2 : 1;
            sendeAnSpieler(aktiverSpieler, "DRAN " + anzahlObjekte);
            sendeAnSpieler(wartenderSpieler, "WARTEN " + anzahlObjekte);
        }
    }

    // =========================================================================
    // MEILENSTEIN 4: VERBINDUNGSABBRUCH (processClosingConnection)
    // =========================================================================

    /**
     * Wird automatisch aufgerufen, wenn ein Client die Verbindung trennt.
     * 
     * AUFGABE 4:
     * - Pruefen, ob ein registrierter Spieler gegangen ist.
     * - Falls das Spiel lief: Den verbleibenden Spieler informieren und das Spiel beenden.
     */
    @Override
    public void processClosingConnection(String pClientIP, int pClientPort) {
        System.out.println("<<< Verbindung getrennt von: " + pClientIP + ":" + pClientPort);

        if (istSpieler1(pClientIP, pClientPort)) {
            System.out.println("[SERVER] Spieler 1 hat die Verbindung getrennt!");
            if (spielAktiv && spieler2IP != null) {
                sendeAnSpieler(2, "INFO Spieler 1 hat das Spiel verlassen. Spiel abgebrochen.");
            }
            zuruecksetzen();
        } else if (istSpieler2(pClientIP, pClientPort)) {
            System.out.println("[SERVER] Spieler 2 hat die Verbindung getrennt!");
            if (spielAktiv && spieler1IP != null) {
                sendeAnSpieler(1, "INFO Spieler 2 hat das Spiel verlassen. Spiel abgebrochen.");
            }
            zuruecksetzen();
        }
    }
}
