/**
 * Abstrakte Klasse Client
 * 
 * Abitur-Vorgabeklasse (NRW) fuer Rechnernetze.
 * 
 * Kapselt das Verhalten eines TCP-Netzwerk-Clients als BLACKBOX.
 * 
 * WARUM IST DIESE KLASSE ABSTRAKT?
 * Diese Klasse enthaelt die gesamte Netzwerk-Maschinerie (Verbindungsaufbau,
 * Sockets, Streams, paralleler Empfangs-Thread im Hintergrund).
 * Sie kann jedoch NICHT wissen, welche Anwendung (Chat, RPG-Duell, Wetterstation)
 * damit gebaut werden soll!
 * 
 * Daher enthaelt sie die ABSTRAKTE Methode 'processMessage(String pMessage)'.
 * Jede konkrete Unterklasse (z. B. 'EchoClient extends Client') MUSS diese Methode
 * ueberschreiben (@Override), um auf eingehende Nachrichten zu reagieren.
 * 
 * @author Qualitaets- und UnterstuetzungsAgentur - Landesinstitut fuer Schule (QUA-LiS NRW)
 * @version Schuljahr 2026/27 (Kommentierte Schulausgabe)
 */
public abstract class Client {

    private MessageHandler messageHandler;

    /**
     * Privater Hintergrund-Thread fuer den asynchronen Empfang.
     * Sorgt dafuer, dass das Hauptprogramm NICHT einfriert, waehrend auf
     * Daten aus dem Netzwerk gewartet wird.
     */
    private class MessageHandler extends Thread {
        private Connection activeConnection;
        private boolean isRunning;

        private MessageHandler(String pServerIP, int pServerPort) {
            this.isRunning = true;
            this.activeConnection = new Connection(pServerIP, pServerPort);
            if (this.activeConnection.getRemoteIP() != null) {
                // Thread starten -> fuehrt run() nebenlaeufig aus
                this.start();
            } else {
                this.activeConnection = null;
                this.isRunning = false;
            }
        }

        @Override
        public void run() {
            while (this.isRunning) {
                // Wartet blockierend auf die naechste Zeile
                String message = this.activeConnection.receive();
                if (message != null) {
                    // KLINGEL-EFFEKT: Eingehende Nachricht an die Unterklasse weiterreichen!
                    processMessage(message);
                } else {
                    // Verbindung wurde durch den Server beendet
                    this.isRunning = false;
                    close();
                }
            }
        }

        private void send(String pMessage) {
            if (this.activeConnection != null) {
                this.activeConnection.send(pMessage);
            }
        }

        private void closeConnection() {
            if (this.isRunning) {
                this.isRunning = false;
                if (this.activeConnection != null) {
                    this.activeConnection.close();
                }
            }
        }
    }

    /**
     * Konstruktor: Baut eine Verbindung zum angegebenen Server auf.
     * 
     * @param pServerIP   IP-Adresse des Servers (z. B. "127.0.0.1" fuer lokalen Test)
     * @param pServerPort Portnummer des Servers (z. B. 50000)
     */
    public Client(String pServerIP, int pServerPort) {
        this.messageHandler = new MessageHandler(pServerIP, pServerPort);
    }

    /**
     * Prueft, ob der Client aktuell mit einem Server verbunden ist.
     * 
     * @return true, falls eine Verbindung aktiv ist; sonst false
     */
    public boolean isConnected() {
        return (this.messageHandler != null && this.messageHandler.activeConnection != null && this.messageHandler.isRunning);
    }

    /**
     * Sendet eine Textzeile an den Server.
     * 
     * @param pMessage Die Nachricht als Zeichenkette
     */
    public void send(String pMessage) {
        if (this.isConnected()) {
            this.messageHandler.send(pMessage);
        } else {
            System.err.println("[Client-Hinweis] Senden nicht moeglich: Keine aktive Verbindung!");
        }
    }

    /**
     * Trennt die Verbindung zum Server ordnungsgemaess.
     */
    public void close() {
        if (this.isConnected()) {
            this.messageHandler.closeConnection();
        }
    }

    /**
     * ABSTRAKTE HOOK-METHODE (Der Vertrag):
     * 
     * Diese Methode besitzt hier KEINEN Methodenrumpf ({ }), sondern nur ein Semikolon.
     * Sie MUSS von jeder Unterklasse ueberschrieben werden!
     * 
     * Sobald eine Nachricht vom Server eintrifft, ruft das Framework
     * diese Methode automatisch auf und uebergibt den Text.
     * 
     * @param pMessage Die vom Server empfangene Textnachricht
     */
    public abstract void processMessage(String pMessage);
}
