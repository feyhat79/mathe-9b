/**
 * Die Klasse Bild stellt eine zusammengesetzte Zeichnung aus mehreren
 * geometrischen Figuren dar (Wand, Dach, Fenster und Sonne).
 * 
 * Sie demonstriert die objektorientierte Komposition ("Hat-ein"-Beziehung):
 * Ein Objekt der Klasse Bild erzeugt und steuert mehrere andere Objekte.
 * 
 * @author Informatik EF (Unterrichtsreihe BlueJ & Java)
 * @version 2026/2027
 */
public class Bild {

    // --- 1. Attribute (Objektreferenzen / "Hat-ein"-Beziehungen) ---
    private Quadrat wand;
    private Dreieck dach;
    private Quadrat fenster;
    private Kreis sonne;
    private boolean istGezeichnet; 

    /**
     * Konstruktor: Erzeugt ein neues Bild.
     * 
     * Hier werden die Konstruktoren der einzelnen Figuren aufgerufen.
     * Die Figuren existieren nun im Arbeitsspeicher, sind aber noch unsichtbar.
     */
    public Bild() {
        wand = new Quadrat();
        dach = new Dreieck();
        fenster = new Quadrat();
        sonne = new Kreis();
        istGezeichnet = false;
    }

    /**
     * Zeichnet die Gesamtszene (Haus und Sonne) auf die Leinwand.
     */
    public void zeichne() {
        if (!istGezeichnet) {
            // Wand einrichten
            wand.groesseAendern(120);
            wand.farbeAendern("rot");
            wand.horizontalBewegen(-50);
            wand.vertikalBewegen(80);
            wand.sichtbarMachen();

            // Fenster einrichten
            fenster.farbeAendern("schwarz");
            fenster.groesseAendern(35);
            fenster.horizontalBewegen(-15);
            fenster.vertikalBewegen(120);
            fenster.sichtbarMachen();

            // Dach einrichten
            dach.farbeAendern("gruen");
            dach.groesseAendern(60, 150);
            dach.horizontalBewegen(20);
            dach.vertikalBewegen(45);
            dach.sichtbarMachen();

            // Sonne einrichten
            sonne.farbeAendern("gelb");
            sonne.groesseAendern(65);
            sonne.horizontalBewegen(125);
            sonne.vertikalBewegen(-30);
            sonne.sichtbarMachen();

            istGezeichnet = true;
        }
    }

    /**
     * Loescht das Bild von der Leinwand (macht alle Figuren unsichtbar).
     */
    public void loesche() {
        if (istGezeichnet) {
            wand.unsichtbarMachen();
            fenster.unsichtbarMachen();
            dach.unsichtbarMachen();
            sonne.unsichtbarMachen();
            istGezeichnet = false;
        }
    }

    /**
     * Vertiefungsaufgabe: Laesst die Sonne langsam untergehen.
     */
    public void sonnenuntergang() {
        if (istGezeichnet) {
            sonne.langsamVertikalBewegen(260);
            sonne.farbeAendern("blau");
        }
    }

    /**
     * Vertiefungsaufgabe: Schaltet auf Nachtmodus um (Licht im Fenster an!).
     */
    public void nachtModus() {
        if (istGezeichnet) {
            sonne.unsichtbarMachen();
            wand.farbeAendern("blau");
            fenster.farbeAendern("gelb"); // Licht brennt im Haus
        }
    }
}
