import java.awt.Polygon;

/**
 * Ein Dreieck, das manipuliert werden kann und sich selbst auf einer
 * Leinwand zeichnet.
 *
 * @author Michael Koelling, David J. Barnes, Axel Schmolitzky (angepasst fuer EF)
 * @version 2026/2027
 */
public class Dreieck {

    // --- Attribute (Zustand des Objekts) ---
    private int hoehe;
    private int breite;
    private int xPosition;
    private int yPosition;
    private String farbe;
    private boolean istSichtbar;

    /**
     * Erzeuge ein neues Dreieck an einer Standardposition mit einer Standardfarbe.
     */
    public Dreieck() {
        hoehe = 60;
        breite = 70;
        xPosition = 210;
        yPosition = 140;
        farbe = "gruen";
        istSichtbar = false;
    }

    /**
     * Mache dieses Dreieck sichtbar. Wenn es bereits sichtbar ist, tue nichts.
     */
    public void sichtbarMachen() {
        istSichtbar = true;
        zeichne();
    }

    /**
     * Mache dieses Dreieck unsichtbar. Wenn es bereits unsichtbar ist, tue nichts.
     */
    public void unsichtbarMachen() {
        loesche();
        istSichtbar = false;
    }

    /**
     * Bewege dieses Dreieck einige Bildschirmpunkte nach rechts.
     */
    public void nachRechtsBewegen() {
        horizontalBewegen(20);
    }

    /**
     * Bewege dieses Dreieck einige Bildschirmpunkte nach links.
     */
    public void nachLinksBewegen() {
        horizontalBewegen(-20);
    }

    /**
     * Bewege dieses Dreieck einige Bildschirmpunkte nach oben.
     */
    public void nachObenBewegen() {
        vertikalBewegen(-20);
    }

    /**
     * Bewege dieses Dreieck einige Bildschirmpunkte nach unten.
     */
    public void nachUntenBewegen() {
        vertikalBewegen(20);
    }

    /**
     * Bewege dieses Dreieck horizontal um 'distanz' Bildschirmpunkte.
     */
    public void horizontalBewegen(int distanz) {
        loesche();
        xPosition += distanz;
        zeichne();
    }

    /**
     * Bewege dieses Dreieck vertikal um 'distanz' Bildschirmpunkte.
     */
    public void vertikalBewegen(int distanz) {
        loesche();
        yPosition += distanz;
        zeichne();
    }

    /**
     * Bewege dieses Dreieck langsam horizontal um 'distanz' Bildschirmpunkte.
     */
    public void langsamHorizontalBewegen(int distanz) {
        int delta;
        if (distanz < 0) {
            delta = -1;
            distanz = -distanz;
        } else {
            delta = 1;
        }

        for (int i = 0; i < distanz; i++) {
            xPosition += delta;
            zeichne();
            Leinwand.getLeinwand().warte(10);
        }
    }

    /**
     * Bewege dieses Dreieck langsam vertikal um 'distanz' Bildschirmpunkte.
     */
    public void langsamVertikalBewegen(int distanz) {
        int delta;
        if (distanz < 0) {
            delta = -1;
            distanz = -distanz;
        } else {
            delta = 1;
        }

        for (int i = 0; i < distanz; i++) {
            yPosition += delta;
            zeichne();
            Leinwand.getLeinwand().warte(10);
        }
    }

    /**
     * Aendere die Hoehe und Breite dieses Dreiecks in 'neueHoehe' und 'neueBreite'.
     * Beide Werte muessen groesser oder gleich Null sein.
     */
    public void groesseAendern(int neueHoehe, int neueBreite) {
        loesche();
        hoehe = neueHoehe;
        breite = neueBreite;
        zeichne();
    }

    /**
     * Aendere die Farbe dieses Dreiecks in 'neueFarbe'.
     * Gueltige Farben sind: "rot", "gelb", "blau", "gruen", "orange", "violett", "schwarz", "weiss", "grau".
     */
    public void farbeAendern(String neueFarbe) {
        farbe = neueFarbe;
        zeichne();
    }

    /**
     * Zeichne dieses Dreieck mit seinen aktuellen Werten auf der Leinwand.
     */
    private void zeichne() {
        if (istSichtbar) {
            Leinwand leinwand = Leinwand.getLeinwand();
            int[] xpoints = { xPosition, xPosition + (breite / 2), xPosition - (breite / 2) };
            int[] ypoints = { yPosition, yPosition + hoehe, yPosition + hoehe };
            leinwand.zeichne(this, farbe, new Polygon(xpoints, ypoints, 3));
        }
    }

    /**
     * Loesche dieses Dreieck von der Leinwand.
     */
    private void loesche() {
        if (istSichtbar) {
            Leinwand leinwand = Leinwand.getLeinwand();
            leinwand.entferne(this);
        }
    }
}
