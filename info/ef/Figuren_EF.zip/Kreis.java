import java.awt.geom.Ellipse2D;

/**
 * Ein Kreis, der manipuliert werden kann und sich selbst auf einer
 * Leinwand zeichnet.
 *
 * @author Michael Koelling, David J. Barnes, Axel Schmolitzky (angepasst fuer EF)
 * @version 2026/2027
 */
public class Kreis {

    // --- Attribute (Zustand des Objekts) ---
    private int groesse;
    private int xPosition;
    private int yPosition;
    private String farbe;
    private boolean istSichtbar;

    /**
     * Erzeuge einen neuen Kreis an einer Standardposition mit einer Standardfarbe.
     */
    public Kreis() {
        groesse = 68;
        xPosition = 230;
        yPosition = 90;
        farbe = "blau";
        istSichtbar = false;
    }

    /**
     * Mache diesen Kreis sichtbar. Wenn er bereits sichtbar ist, tue nichts.
     */
    public void sichtbarMachen() {
        istSichtbar = true;
        zeichne();
    }

    /**
     * Mache diesen Kreis unsichtbar. Wenn er bereits unsichtbar ist, tue nichts.
     */
    public void unsichtbarMachen() {
        loesche();
        istSichtbar = false;
    }

    /**
     * Bewege diesen Kreis einige Bildschirmpunkte nach rechts.
     */
    public void nachRechtsBewegen() {
        horizontalBewegen(20);
    }

    /**
     * Bewege diesen Kreis einige Bildschirmpunkte nach links.
     */
    public void nachLinksBewegen() {
        horizontalBewegen(-20);
    }

    /**
     * Bewege diesen Kreis einige Bildschirmpunkte nach oben.
     */
    public void nachObenBewegen() {
        vertikalBewegen(-20);
    }

    /**
     * Bewege diesen Kreis einige Bildschirmpunkte nach unten.
     */
    public void nachUntenBewegen() {
        vertikalBewegen(20);
    }

    /**
     * Bewege diesen Kreis horizontal um 'distanz' Bildschirmpunkte.
     */
    public void horizontalBewegen(int distanz) {
        loesche();
        xPosition += distanz;
        zeichne();
    }

    /**
     * Bewege diesen Kreis vertikal um 'distanz' Bildschirmpunkte.
     */
    public void vertikalBewegen(int distanz) {
        loesche();
        yPosition += distanz;
        zeichne();
    }

    /**
     * Bewege diesen Kreis langsam horizontal um 'distanz' Bildschirmpunkte.
     */
    public void langsamHorizontalBewegen(int distanz) {
        int delta;
        if (distanz < 0) {
            delta = -1;
            distanz = -distanz;
        } else {
            delta = 1;
        }

        for (int i = 0; i < distanz; i++) {
            xPosition += delta;
            zeichne();
            Leinwand.getLeinwand().warte(10);
        }
    }

    /**
     * Bewege diesen Kreis langsam vertikal um 'distanz' Bildschirmpunkte.
     */
    public void langsamVertikalBewegen(int distanz) {
        int delta;
        if (distanz < 0) {
            delta = -1;
            distanz = -distanz;
        } else {
            delta = 1;
        }

        for (int i = 0; i < distanz; i++) {
            yPosition += delta;
            zeichne();
            Leinwand.getLeinwand().warte(10);
        }
    }

    /**
     * Aendere den Durchmesser dieses Kreises in 'neueGroesse' (in Bildschirmpunkten).
     * 'neueGroesse' muss groesser oder gleich Null sein.
     */
    public void groesseAendern(int neueGroesse) {
        loesche();
        groesse = neueGroesse;
        zeichne();
    }

    /**
     * Aendere die Farbe dieses Kreises in 'neueFarbe'.
     * Gueltige Farben sind: "rot", "gelb", "blau", "gruen", "orange", "violett", "schwarz", "weiss", "grau".
     */
    public void farbeAendern(String neueFarbe) {
        farbe = neueFarbe;
        zeichne();
    }

    /**
     * Zeichne diesen Kreis mit seinen aktuellen Werten auf der Leinwand.
     */
    private void zeichne() {
        if (istSichtbar) {
            Leinwand leinwand = Leinwand.getLeinwand();
            leinwand.zeichne(this, farbe, new Ellipse2D.Double(xPosition, yPosition, groesse, groesse));
        }
    }

    /**
     * Loesche diesen Kreis von der Leinwand.
     */
    private void loesche() {
        if (istSichtbar) {
            Leinwand leinwand = Leinwand.getLeinwand();
            leinwand.entferne(this);
        }
    }
}
