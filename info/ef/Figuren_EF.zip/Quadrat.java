import java.awt.Rectangle;

/**
 * Ein Quadrat, das manipuliert werden kann und sich selbst auf einer
 * Leinwand zeichnet.
 *
 * @author Michael Koelling, David J. Barnes, Axel Schmolitzky (angepasst fuer EF)
 * @version 2026/2027
 */
public class Quadrat {

    // --- Attribute (Zustand des Objekts) ---
    private int groesse;
    private int xPosition;
    private int yPosition;
    private String farbe;
    private boolean istSichtbar;

    /**
     * Erzeuge ein neues Quadrat an einer Standardposition mit einer Standardfarbe.
     */
    public Quadrat() {
        groesse = 60;
        xPosition = 80;
        yPosition = 140;
        farbe = "rot";
        istSichtbar = false;
    }

    /**
     * Mache dieses Quadrat sichtbar. Wenn es bereits sichtbar ist, tue nichts.
     */
    public void sichtbarMachen() {
        istSichtbar = true;
        zeichne();
    }

    /**
     * Mache dieses Quadrat unsichtbar. Wenn es bereits unsichtbar ist, tue nichts.
     */
    public void unsichtbarMachen() {
        loesche();
        istSichtbar = false;
    }

    /**
     * Bewege dieses Quadrat einige Bildschirmpunkte nach rechts.
     */
    public void nachRechtsBewegen() {
        horizontalBewegen(20);
    }

    /**
     * Bewege dieses Quadrat einige Bildschirmpunkte nach links.
     */
    public void nachLinksBewegen() {
        horizontalBewegen(-20);
    }

    /**
     * Bewege dieses Quadrat einige Bildschirmpunkte nach oben.
     */
    public void nachObenBewegen() {
        vertikalBewegen(-20);
    }

    /**
     * Bewege dieses Quadrat einige Bildschirmpunkte nach unten.
     */
    public void nachUntenBewegen() {
        vertikalBewegen(20);
    }

    /**
     * Bewege dieses Quadrat horizontal um 'distanz' Bildschirmpunkte.
     */
    public void horizontalBewegen(int distanz) {
        loesche();
        xPosition += distanz;
        zeichne();
    }

    /**
     * Bewege dieses Quadrat vertikal um 'distanz' Bildschirmpunkte.
     */
    public void vertikalBewegen(int distanz) {
        loesche();
        yPosition += distanz;
        zeichne();
    }

    /**
     * Bewege dieses Quadrat langsam horizontal um 'distanz' Bildschirmpunkte.
     */
    public void langsamHorizontalBewegen(int distanz) {
        int delta;
        if (distanz < 0) {
            delta = -1;
            distanz = -distanz;
        } else {
            delta = 1;
        }

        for (int i = 0; i < distanz; i++) {
            xPosition += delta;
            zeichne();
            Leinwand.getLeinwand().warte(10);
        }
    }

    /**
     * Bewege dieses Quadrat langsam vertikal um 'distanz' Bildschirmpunkte.
     */
    public void langsamVertikalBewegen(int distanz) {
        int delta;
        if (distanz < 0) {
            delta = -1;
            distanz = -distanz;
        } else {
            delta = 1;
        }

        for (int i = 0; i < distanz; i++) {
            yPosition += delta;
            zeichne();
            Leinwand.getLeinwand().warte(10);
        }
    }

    /**
     * Aendere die Groesse dieses Quadrates in 'neueGroesse'.
     * 'neueGroesse' muss groesser oder gleich Null sein.
     */
    public void groesseAendern(int neueGroesse) {
        loesche();
        groesse = neueGroesse;
        zeichne();
    }

    /**
     * Aendere die Farbe dieses Quadrates in 'neueFarbe'.
     * Gueltige Farben sind: "rot", "gelb", "blau", "gruen", "orange", "violett", "schwarz", "weiss", "grau".
     */
    public void farbeAendern(String neueFarbe) {
        farbe = neueFarbe;
        zeichne();
    }

    /**
     * Zeichne dieses Quadrat mit seinen aktuellen Werten auf der Leinwand.
     */
    private void zeichne() {
        if (istSichtbar) {
            Leinwand leinwand = Leinwand.getLeinwand();
            leinwand.zeichne(this, farbe, new Rectangle(xPosition, yPosition, groesse, groesse));
        }
    }

    /**
     * Loesche dieses Quadrat von der Leinwand.
     */
    private void loesche() {
        if (istSichtbar) {
            Leinwand leinwand = Leinwand.getLeinwand();
            leinwand.entferne(this);
        }
    }
}
