
public class Auto
{
   Quadrat tuer1; 
   Quadrat tuer2; 
   Quadrat dach; 
   Kreis reifenLinks; 
   Kreis reifenRechts; 
   
   void zeichen()
   {
       Quadrat tuer1 = new Quadrat(); 
       Quadrat tuer2 = new Quadrat();
       Quadrat dach = new Quadrat();
       Kreis reifenLinks = new Kreis();
       Kreis reifenRechts = new Kreis();
   }
}