import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.*;

/**
 * Leinwand ist eine Klasse, die einfache Zeichenoperationen auf einer
 * leinwandartigen Zeichenflaeche ermoeglicht.
 * Sie ist als Singleton aufgebaut, damit alle grafischen Objekte dieselbe
 * Zeichenflaeche nutzen.
 *
 * @author Bruce Quig, Michael Koelling, Axel Schmolitzky (angepasst fuer EF Informatik)
 * @version 2026/2027
 */
public class Leinwand {

    private static Leinwand leinwandSingleton;

    /**
     * Fabrikmethode, die eine Referenz auf das einzige Leinwand-Objekt zurueckliefert.
     */
    public static Leinwand getLeinwand() {
        if (leinwandSingleton == null) {
            leinwandSingleton = new Leinwand("Zeichenfenster Informatik EF", 600, 500, Color.white);
        }
        leinwandSingleton.setSichtbar(true);
        return leinwandSingleton;
    }

    // --- Instanzvariablen ---
    private JFrame fenster;
    private Zeichenflaeche zeichenflaeche;
    private Graphics2D graphic;
    private Color hintergrundfarbe;
    private Image leinwandImage;
    private List<Object> figuren;
    private Map<Object, ShapeMitFarbe> figurZuShape;

    /**
     * Erzeuge eine Leinwand.
     */
    private Leinwand(String titel, int breite, int hoehe, Color grundfarbe) {
        fenster = new JFrame();
        zeichenflaeche = new Zeichenflaeche();
        fenster.setContentPane(zeichenflaeche);
        fenster.setTitle(titel);
        fenster.setLocation(50, 50);
        zeichenflaeche.setPreferredSize(new Dimension(breite, hoehe));
        hintergrundfarbe = grundfarbe;
        fenster.pack();
        figuren = new ArrayList<Object>();
        figurZuShape = new HashMap<Object, ShapeMitFarbe>();
    }

    /**
     * Setze den Sichtbarkeitsstatus dieser Leinwand.
     */
    public void setSichtbar(boolean sichtbar) {
        if (graphic == null) {
            Dimension size = zeichenflaeche.getSize();
            leinwandImage = zeichenflaeche.createImage(size.width, size.height);
            graphic = (Graphics2D) leinwandImage.getGraphics();
            graphic.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            graphic.setColor(hintergrundfarbe);
            graphic.fillRect(0, 0, size.width, size.height);
            graphic.setColor(Color.black);
        }
        fenster.setVisible(sichtbar);
    }

    /**
     * Zeichne fuer das gegebene Figur-Objekt ein Shape.
     */
    public void zeichne(Object figur, String farbe, Shape shape) {
        figuren.remove(figur);
        figuren.add(figur);
        figurZuShape.put(figur, new ShapeMitFarbe(shape, farbe));
        erneutZeichnen();
    }

    /**
     * Entferne die gegebene Figur von der Leinwand.
     */
    public void entferne(Object figur) {
        figuren.remove(figur);
        figurZuShape.remove(figur);
        erneutZeichnen();
    }

    /**
     * Setze die Zeichenfarbe der Leinwand.
     */
    public void setzeFarbe(String farbname) {
        if (farbname.equalsIgnoreCase("rot")) {
            graphic.setColor(new Color(220, 38, 38));
        } else if (farbname.equalsIgnoreCase("schwarz")) {
            graphic.setColor(new Color(17, 24, 39));
        } else if (farbname.equalsIgnoreCase("blau")) {
            graphic.setColor(new Color(37, 99, 235));
        } else if (farbname.equalsIgnoreCase("gelb")) {
            graphic.setColor(new Color(245, 158, 11));
        } else if (farbname.equalsIgnoreCase("gruen")) {
            graphic.setColor(new Color(16, 185, 129));
        } else if (farbname.equalsIgnoreCase("orange")) {
            graphic.setColor(new Color(234, 88, 12));
        } else if (farbname.equalsIgnoreCase("violett")) {
            graphic.setColor(new Color(124, 58, 237));
        } else if (farbname.equalsIgnoreCase("grau")) {
            graphic.setColor(new Color(148, 163, 184));
        } else if (farbname.equalsIgnoreCase("weiss")) {
            graphic.setColor(Color.white);
        } else {
            graphic.setColor(Color.black);
        }
    }

    /**
     * Warte fuer die angegebene Anzahl an Millisekunden.
     */
    public void warte(int millisekunden) {
        try {
            Thread.sleep(millisekunden);
        } catch (Exception e) {
            // Ignoriere Unterbrechung
        }
    }

    /**
     * Zeichne alle Shapes erneut auf die Leinwand.
     */
    private void erneutZeichnen() {
        loeschen();
        for (Object figur : figuren) {
            figurZuShape.get(figur).draw(graphic);
        }
        zeichenflaeche.repaint();
    }

    /**
     * Loesche die gesamte Leinwand.
     */
    private void loeschen() {
        Color original = graphic.getColor();
        graphic.setColor(hintergrundfarbe);
        Dimension size = zeichenflaeche.getSize();
        graphic.fillRect(0, 0, size.width, size.height);
        graphic.setColor(original);
    }

    // --- Interne Hilfsklassen ---

    private class Zeichenflaeche extends JPanel {
        public void paint(Graphics g) {
            g.drawImage(leinwandImage, 0, 0, null);
        }
    }

    private class ShapeMitFarbe {
        private Shape shape;
        private String farbe;

        public ShapeMitFarbe(Shape shape, String farbe) {
            this.shape = shape;
            this.farbe = farbe;
        }

        public void draw(Graphics2D graphic) {
            setzeFarbe(farbe);
            graphic.fill(shape);
        }
    }
}
