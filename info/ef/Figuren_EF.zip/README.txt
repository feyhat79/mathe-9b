------------------------------------------------------------------------
PROJEKTBEZEICHNUNG: Figuren_EF
PROJEKTZWECK: Einstieg in die objektorientierte Modellierung und Programmierung (EF Informatik)
VERSION: 2026/2027
AUTOREN: Michael Kölling, David J. Barnes, Axel Schmolitzky (angepasst für EF)
------------------------------------------------------------------------

BENUTZERHINWEISE:
1. Erzeuge durch Rechtsklick auf eine der Klassen (Kreis, Quadrat, Dreieck)
   ein konkretes Objekt auf der Werkbank (Object Bench).
2. Klicke mit der rechten Maustaste auf das erzeugte Objekt, um Methoden
   aufzurufen (z.B. sichtbarMachen(), farbeAendern(), horizontalBewegen()).
3. Öffne über Rechtsklick -> "Inspizieren" den Objekt-Inspektor, um die
   Attribute (den aktuellen Zustand) des Objekts zu beobachten.
